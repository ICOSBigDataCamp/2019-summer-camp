--
-- File generated with SQLiteStudio v3.1.1 on Wed Jun 19 23:34:02 2019
--
-- Text encoding used: UTF-8
--
PRAGMA foreign_keys = off;
BEGIN TRANSACTION;

-- Table: Employees
DROP TABLE IF EXISTS Employees;
CREATE TABLE Employees (EID INT PRIMARY KEY, firstname VARCHAR, lastname VARCHAR, email VARCHAR, phonenumber VARCHAR, storeID INTEGER, status INTEGER, startdate DATETIME, enddate DATETIME);
INSERT INTO Employees (EID, firstname, lastname, email, phonenumber, storeID, status, startdate, enddate) VALUES (8011436, 'Sarita', 'Ali', 'sarita.ali@yahoo.com', '567-551-3003', 7341, 0, '2012-08-15', '2014-01-08');
INSERT INTO Employees (EID, firstname, lastname, email, phonenumber, storeID, status, startdate, enddate) VALUES (8040493, 'Rhonda', 'Allen', 'rhonda.allen@yahoo.com', '567-667-5552', 7341, 0, '2012-08-05', '2014-04-03');
INSERT INTO Employees (EID, firstname, lastname, email, phonenumber, storeID, status, startdate, enddate) VALUES (8027143, 'Alphonso', 'Alvarado', 'phonso.alvarado@gmail.com', '248-456-6643', 7341, 0, '2015-05-18', '2016-05-08');
INSERT INTO Employees (EID, firstname, lastname, email, phonenumber, storeID, status, startdate, enddate) VALUES (8035571, 'Courtney', 'Amaez', 'camaez@yahoo.com', '567-777-7032', 7341, 1, '2013-08-08', '');
INSERT INTO Employees (EID, firstname, lastname, email, phonenumber, storeID, status, startdate, enddate) VALUES (8038965, 'Jamie', 'Bang', 'jamie.bang@emich.edu', '248-678-3240', 7341, 1, '2014-11-22', '');
INSERT INTO Employees (EID, firstname, lastname, email, phonenumber, storeID, status, startdate, enddate) VALUES (8019164, 'Rachel', 'Bee', 'thebeesting@hotmail.com', '810-255-4751', 7341, 0, '2015-02-13', '2016-06-04');
INSERT INTO Employees (EID, firstname, lastname, email, phonenumber, storeID, status, startdate, enddate) VALUES (8013278, 'August', 'Brown', 'brownaugust@gmail.com', '248-566-4079', 7341, 1, '2014-08-05', '');
INSERT INTO Employees (EID, firstname, lastname, email, phonenumber, storeID, status, startdate, enddate) VALUES (8064453, 'Felecia', 'Bye', 'felibye@umich.edu', '734-667-4143', 7341, 0, '2011-12-24', '2013-03-09');
INSERT INTO Employees (EID, firstname, lastname, email, phonenumber, storeID, status, startdate, enddate) VALUES (8004778, 'Lakeesha', 'Childs', 'lakeesha.childs@gmail.com', '810-777-4503', 7341, 0, '2013-12-05', '2014-04-14');
INSERT INTO Employees (EID, firstname, lastname, email, phonenumber, storeID, status, startdate, enddate) VALUES (8026077, 'Gemma', 'Chitty', 'gemmac@hotmail.co.uk', '734-551-7481', 7341, 1, '2011-09-04', '');
INSERT INTO Employees (EID, firstname, lastname, email, phonenumber, storeID, status, startdate, enddate) VALUES (8027219, 'Cameron', 'Cooper', 'hoopercooper@hotmail.com', '517-543-4690', 7341, 0, '2014-04-24', '2016-04-30');
INSERT INTO Employees (EID, firstname, lastname, email, phonenumber, storeID, status, startdate, enddate) VALUES (8011467, 'Fatimah', 'Crawford', 'fatimahcrawford@gmail.com', '734-790-3419', 7341, 1, '2015-09-20', '');
INSERT INTO Employees (EID, firstname, lastname, email, phonenumber, storeID, status, startdate, enddate) VALUES (8004878, 'Odette', 'Cruz', 'odette.cruz@gmail.com', '248-255-5812', 7341, 0, '2011-12-08', '2015-09-27');
INSERT INTO Employees (EID, firstname, lastname, email, phonenumber, storeID, status, startdate, enddate) VALUES (8010873, 'Vashti', 'Deb', 'vashti.deb@hotmail.com', '216-567-3885', 7341, 1, '2012-05-22', '');
INSERT INTO Employees (EID, firstname, lastname, email, phonenumber, storeID, status, startdate, enddate) VALUES (8012412, 'Danika', 'Dellatorre', 'danikadella@gmail.com', '567-232-8598', 7341, 0, '2011-01-16', '2015-04-19');
INSERT INTO Employees (EID, firstname, lastname, email, phonenumber, storeID, status, startdate, enddate) VALUES (8011824, 'Tasha', 'Dennish', 'tasha.dennish@yahoo.com', '248-232-7701', 7341, 1, '2015-06-19', '');
INSERT INTO Employees (EID, firstname, lastname, email, phonenumber, storeID, status, startdate, enddate) VALUES (8019548, 'Hortense', 'Eastwood', 'tensieastwood@gmail.com', '313-255-2112', 7341, 0, '2014-08-04', '2016-02-11');
INSERT INTO Employees (EID, firstname, lastname, email, phonenumber, storeID, status, startdate, enddate) VALUES (8021134, 'Zachary', 'Ehrenreich', 'ehrenreichzachary@gmail.com', '567-478-6251', 7341, 0, '2011-02-13', '2014-06-26');
INSERT INTO Employees (EID, firstname, lastname, email, phonenumber, storeID, status, startdate, enddate) VALUES (8018057, 'Everett', 'Embry', 'embryeverett@gmail.com', '734-999-6993', 7341, 1, '2012-01-28', '');
INSERT INTO Employees (EID, firstname, lastname, email, phonenumber, storeID, status, startdate, enddate) VALUES (8017303, 'Thomas', 'Emerald', 'temerald@hotmail.com', '734-234-3937', 7341, 1, '2012-08-30', '');
INSERT INTO Employees (EID, firstname, lastname, email, phonenumber, storeID, status, startdate, enddate) VALUES (8013419, 'Adele', 'Frank', 'adelefrank68@aol.com', '734-566-6147', 7341, 0, '2010-12-03', '2011-03-10');
INSERT INTO Employees (EID, firstname, lastname, email, phonenumber, storeID, status, startdate, enddate) VALUES (8027793, 'Quinn', 'Fuentes', 'quinn.fuentes@yahoo.com', '567-790-5381', 7341, 0, '2015-08-27', '2016-05-25');
INSERT INTO Employees (EID, firstname, lastname, email, phonenumber, storeID, status, startdate, enddate) VALUES (8008616, 'Geoffrey', 'Groos', 'groos@yahoo.com', '734-777-4364', 7341, 1, '2011-03-13', '');
INSERT INTO Employees (EID, firstname, lastname, email, phonenumber, storeID, status, startdate, enddate) VALUES (8009353, 'Emily', 'Ingrahmn', 'eingra@umich.edu', '313-543-7611', 7341, 0, '2012-11-09', '2015-05-16');
INSERT INTO Employees (EID, firstname, lastname, email, phonenumber, storeID, status, startdate, enddate) VALUES (8044091, 'Emily', 'Ingram', 'em.ingram@yahoo.com', '567-566-6355', 7341, 1, '2015-08-25', '');
INSERT INTO Employees (EID, firstname, lastname, email, phonenumber, storeID, status, startdate, enddate) VALUES (8025463, 'Tina', 'Ismail', 'tina.ismail@emich.edu', '313-234-4127', 7341, 0, '2014-09-27', '2015-05-08');
INSERT INTO Employees (EID, firstname, lastname, email, phonenumber, storeID, status, startdate, enddate) VALUES (8028023, 'Jenna', 'Unger', 'jenna.unger@hotmail.com', '313-567-8390', 7341, 1, '2011-10-13', '');
INSERT INTO Employees (EID, firstname, lastname, email, phonenumber, storeID, status, startdate, enddate) VALUES (8009331, 'Taronda', 'Jenkins', 'taronda.jenkins@yahoo.com', '313-225-4092', 7341, 1, '2010-02-24', '');
INSERT INTO Employees (EID, firstname, lastname, email, phonenumber, storeID, status, startdate, enddate) VALUES (8017434, 'Sara', 'Johnson', 'sjohnson14@gmail.com', '248-566-8524', 7341, 1, '2013-09-29', '');
INSERT INTO Employees (EID, firstname, lastname, email, phonenumber, storeID, status, startdate, enddate) VALUES (8018503, 'Sarah', 'Johnson', 'sjohnson12@yahoo.com', '216-534-8799', 7341, 1, '2014-12-16', '');
INSERT INTO Employees (EID, firstname, lastname, email, phonenumber, storeID, status, startdate, enddate) VALUES (8009159, 'Amy', 'Johnston', 'theotheramyjohnston@gmail.com', '313-232-3685', 7341, 1, '2011-08-04', '');
INSERT INTO Employees (EID, firstname, lastname, email, phonenumber, storeID, status, startdate, enddate) VALUES (8013185, 'Sera', 'Johnston', 'sjohnston15@outlook.com', '734-543-8639', 7341, 1, '2014-06-17', '');
INSERT INTO Employees (EID, firstname, lastname, email, phonenumber, storeID, status, startdate, enddate) VALUES (8006866, 'Ashley', 'Jones', 'ashleyjones12@gmail.com', '646-456-7368', 7341, 0, '2011-08-26', '2016-03-02');
INSERT INTO Employees (EID, firstname, lastname, email, phonenumber, storeID, status, startdate, enddate) VALUES (8007383, 'Yolanda', 'Jones', 'yolandajones@hotmail.com', '517-234-7976', 7341, 1, '2011-06-25', '');
INSERT INTO Employees (EID, firstname, lastname, email, phonenumber, storeID, status, startdate, enddate) VALUES (8012347, 'Nancy', 'Jones', 'nancy.jones@gmail.com', '906-790-5803', 7341, 1, '2014-05-31', '');
INSERT INTO Employees (EID, firstname, lastname, email, phonenumber, storeID, status, startdate, enddate) VALUES (8029290, 'Nancy', 'Jones', 'nancee.jones@gmail.com', '906-667-4831', 7341, 1, '2012-12-07', '');
INSERT INTO Employees (EID, firstname, lastname, email, phonenumber, storeID, status, startdate, enddate) VALUES (8038337, 'Danika', 'Kane', 'kane.danika@gmail.com', '567-225-6007', 7341, 0, '2014-04-14', '2014-10-17');
INSERT INTO Employees (EID, firstname, lastname, email, phonenumber, storeID, status, startdate, enddate) VALUES (8026052, 'Cordeila', 'Kaufman', 'deliak1987@yahoo.com', '517-678-6746', 7341, 1, '2014-06-01', '');
INSERT INTO Employees (EID, firstname, lastname, email, phonenumber, storeID, status, startdate, enddate) VALUES (8027960, 'Anton', 'Koldits', 'kolditsanton@hotmail.com', '248-225-8499', 7341, 0, '2015-03-24', '2015-05-06');
INSERT INTO Employees (EID, firstname, lastname, email, phonenumber, storeID, status, startdate, enddate) VALUES (8010312, 'Xenia', 'Kytmanova', 'xenia.kytmanova@hotmail.com', '517-255-5897', 7341, 0, '2012-08-28', '2016-04-16');
INSERT INTO Employees (EID, firstname, lastname, email, phonenumber, storeID, status, startdate, enddate) VALUES (8027861, 'James', 'LaChance', 'lachancejames@hotmail.com', '810-566-2976', 7341, 1, '2011-09-24', '');
INSERT INTO Employees (EID, firstname, lastname, email, phonenumber, storeID, status, startdate, enddate) VALUES (8013880, 'Amber', 'Lake', 'thelakeside@aol.com', '734-242-4029', 7341, 0, '2011-06-21', '2012-04-15');
INSERT INTO Employees (EID, firstname, lastname, email, phonenumber, storeID, status, startdate, enddate) VALUES (8032304, 'Zandra', 'Lee', 'zandralee@hotmail.com', '734-981-5256', 7341, 0, '2012-11-15', '2013-12-24');
INSERT INTO Employees (EID, firstname, lastname, email, phonenumber, storeID, status, startdate, enddate) VALUES (8005633, 'Jeffrey', 'Leroy', 'jeffrey.leroy@yahoo.com', '810-234-4418', 7341, 1, '2013-01-16', '');
INSERT INTO Employees (EID, firstname, lastname, email, phonenumber, storeID, status, startdate, enddate) VALUES (8041425, 'Olivia', 'Levy', 'olivia.levy@gmail.com', '248-234-7720', 7341, 0, '2015-03-15', '2015-06-09');
INSERT INTO Employees (EID, firstname, lastname, email, phonenumber, storeID, status, startdate, enddate) VALUES (8002984, 'Akilah', 'Lewis', 'lewisakilah@yahoo.com', '313-534-2458', 7341, 0, '2014-02-11', '2014-06-21');
INSERT INTO Employees (EID, firstname, lastname, email, phonenumber, storeID, status, startdate, enddate) VALUES (8052104, 'LaToya', 'Lewis', 'latoya.lewis@yahoo.com', '734-678-3431', 7341, 1, '2015-07-28', '');
INSERT INTO Employees (EID, firstname, lastname, email, phonenumber, storeID, status, startdate, enddate) VALUES (8038716, 'Tameka', 'Little', 'tameka.little@hotmail.com', '330-534-3305', 7341, 0, '2013-12-20', '2015-05-10');
INSERT INTO Employees (EID, firstname, lastname, email, phonenumber, storeID, status, startdate, enddate) VALUES (8005932, 'Wendolynn', 'Lopez', 'wlopez@umich.edu', '734-255-2256', 7341, 0, '2011-10-07', '2015-01-30');
INSERT INTO Employees (EID, firstname, lastname, email, phonenumber, storeID, status, startdate, enddate) VALUES (8001647, 'Ruben', 'Lopez', 'rubenlopez@yahoo.com', '517-456-8342', 7341, 1, '2015-09-24', '');
INSERT INTO Employees (EID, firstname, lastname, email, phonenumber, storeID, status, startdate, enddate) VALUES (8009666, 'Abigail', 'Loveland', 'abbylove@gmail.com', '734-225-6825', 7341, 0, '2012-09-05', '2013-04-26');
INSERT INTO Employees (EID, firstname, lastname, email, phonenumber, storeID, status, startdate, enddate) VALUES (8022468, 'Ellie', 'Luk', 'lukkyellie@gmail.com', '248-543-6126', 7341, 1, '2014-01-08', '');
INSERT INTO Employees (EID, firstname, lastname, email, phonenumber, storeID, status, startdate, enddate) VALUES (8055500, 'Maurice', 'Mendel', 'mendelmaurice@hotmail.com', '234-232-3147', 7341, 0, '2012-04-14', '2013-07-28');
INSERT INTO Employees (EID, firstname, lastname, email, phonenumber, storeID, status, startdate, enddate) VALUES (8018856, 'Zoe', 'Pence', 'pencezoe@hotmail.com', '810-225-2581', 7341, 0, '2013-01-24', '2014-09-28');
INSERT INTO Employees (EID, firstname, lastname, email, phonenumber, storeID, status, startdate, enddate) VALUES (8023916, 'Karrin', 'Pomenrants', 'masterchf2000@yahoo.com', '810-543-4206', 7341, 0, '2014-07-15', '2014-10-08');
INSERT INTO Employees (EID, firstname, lastname, email, phonenumber, storeID, status, startdate, enddate) VALUES (8016821, 'Karen', 'Pomerantz', 'kpom@yahoo.com', '810-302-4251', 7341, 0, '2015-09-15', '2016-03-30');
INSERT INTO Employees (EID, firstname, lastname, email, phonenumber, storeID, status, startdate, enddate) VALUES (8027808, 'Katie', 'Ponsoldt', 'katie.ponsoldt@gmail.com', '248-242-6124', 7341, 0, '2013-08-19', '2015-01-18');
INSERT INTO Employees (EID, firstname, lastname, email, phonenumber, storeID, status, startdate, enddate) VALUES (8035258, 'Yvette', 'Ramirez', 'yvetteramirez@hotmail.com', '734-906-6660', 7341, 0, '2015-07-14', '2016-08-29');
INSERT INTO Employees (EID, firstname, lastname, email, phonenumber, storeID, status, startdate, enddate) VALUES (8019026, 'Monca', 'Reeves', 'monca.reeves@gmail.com', '810-232-7916', 7341, 0, '2012-11-30', '2014-07-18');
INSERT INTO Employees (EID, firstname, lastname, email, phonenumber, storeID, status, startdate, enddate) VALUES (8037795, 'Kevin', 'Rosnow', 'rosnowkevin@gmail.com', '419-232-8492', 7341, 1, '2015-03-20', '');
INSERT INTO Employees (EID, firstname, lastname, email, phonenumber, storeID, status, startdate, enddate) VALUES (8057008, 'Monica', 'See', 'msee@gmail.com', '810-242-4403', 7341, 0, '2012-04-01', '2013-07-28');
INSERT INTO Employees (EID, firstname, lastname, email, phonenumber, storeID, status, startdate, enddate) VALUES (8021193, 'Paula', 'Smith', 'paula.smith@gmail.com', '248-777-7345', 7341, 0, '2014-12-04', '2015-02-15');
INSERT INTO Employees (EID, firstname, lastname, email, phonenumber, storeID, status, startdate, enddate) VALUES (8045271, 'Paula ', 'Smith', 'paula.smith@hotmail.com', '313-777-5740', 7341, 0, '2015-02-14', '2016-01-23');
INSERT INTO Employees (EID, firstname, lastname, email, phonenumber, storeID, status, startdate, enddate) VALUES (8057180, 'Ethan', 'Smith', 'smith.ethan@gmail.com', '734-232-7754', 7341, 0, '2014-01-26', '2015-07-17');
INSERT INTO Employees (EID, firstname, lastname, email, phonenumber, storeID, status, startdate, enddate) VALUES (8039371, 'Paula', 'Smith', 'paula.smith@yahoo.com', '734-478-8408', 7341, 1, '2014-06-02', '');
INSERT INTO Employees (EID, firstname, lastname, email, phonenumber, storeID, status, startdate, enddate) VALUES (8024338, 'Caitlin', 'Stein', 'cjstein@yahoo.com', '313-456-6184', 7341, 1, '2014-03-06', '');
INSERT INTO Employees (EID, firstname, lastname, email, phonenumber, storeID, status, startdate, enddate) VALUES (8027198, 'Eden', 'Urquiza', 'edenisurqued@gmail.com', '313-242-8884', 7341, 1, '2014-11-14', '');
INSERT INTO Employees (EID, firstname, lastname, email, phonenumber, storeID, status, startdate, enddate) VALUES (8062592, 'Saita', 'Waters', 'saita.waters@yahoo.com', '313-232-7866', 7341, 0, '2012-04-10', '2015-11-15');
INSERT INTO Employees (EID, firstname, lastname, email, phonenumber, storeID, status, startdate, enddate) VALUES (8009963, 'Vanetta', 'Waters', 'vanetta.waters@hotmail.com', '330-567-3611', 7341, 1, '2011-04-29', '');
INSERT INTO Employees (EID, firstname, lastname, email, phonenumber, storeID, status, startdate, enddate) VALUES (8014461, 'Dawn', 'Willard', 'dwillard@aol.com', '313-678-4571', 7341, 1, '2010-09-13', '');
INSERT INTO Employees (EID, firstname, lastname, email, phonenumber, storeID, status, startdate, enddate) VALUES (8011059, 'Willow', 'Williams', 'willow.williams@hotmail.com', '517-242-4556', 7341, 0, '2013-10-07', '2016-02-12');
INSERT INTO Employees (EID, firstname, lastname, email, phonenumber, storeID, status, startdate, enddate) VALUES (8005719, 'Phoebe', 'Worline', 'phowor@umich.edu', '810-678-2667', 7341, 0, '2014-09-09', '2016-01-19');
INSERT INTO Employees (EID, firstname, lastname, email, phonenumber, storeID, status, startdate, enddate) VALUES ('
', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

COMMIT TRANSACTION;
PRAGMA foreign_keys = on;
