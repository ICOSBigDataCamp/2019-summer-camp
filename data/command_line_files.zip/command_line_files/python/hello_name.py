import sys

if len(sys.argv) < 2:
	print("make sure to include your name when running the command!")
	print("$ python hello_name NAME")
else:
	print("hello", sys.argv[1])