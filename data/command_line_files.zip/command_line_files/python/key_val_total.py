'''this program will take in files which contain lines of the format <KEY VALUE> and output <KEY VALUE TOTAL>'''
'''example run: python key_val_total.py source.txt'''

import sys

if len(sys.argv) < 2:
	print("make sure to include the data file path when running the command!")
	exit(1)	

with open(sys.argv[1], 'r') as f:
	read_data = f.read()

lines = read_data.split('\n')

counts = {}

for line in lines:
	line = line.split()

	if len(line) > 1:
		key = line[0]
		value = line[1]
		if key not in counts:
			counts[key] = {}
			counts[key][value] = 1
		elif value not in counts[key]:
			counts[key][value] = 1
		else:
			counts[key][value] += 1

for key in counts.keys():
	for val in counts[key].keys():
		print(key,val,counts[key][val])
		
	