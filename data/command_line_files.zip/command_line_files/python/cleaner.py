'''this program will take in book files and print the text in lowercase with some punctuation removed'''
'''example run: python cleaner.py source.txt'''

import sys
import string

if len(sys.argv) < 2:
	print("make sure to include the data file path when running the command!")
	exit(1)	

with open(sys.argv[1], 'r') as f:
	read_data = f.read()

cleaner = read_data.translate(str.maketrans('','',string.punctuation)).lower()

print(cleaner)