'''this program will take in book files and print all the words in the format <CHAPTER WORD>'''
'''example run: python chapter_word.py source.txt'''

import sys

if len(sys.argv) < 2:
	print("make sure to include the data file path when running the command!")
	exit(1)	

with open(sys.argv[1], 'r') as f:
	read_data = f.read()

lines = read_data.split('\n')

curr_chapter = ""

for line in lines:
	line = line.split()

	if len(line) > 0 and line[0].lower() == "chapter":
		curr_chapter = line[1]
	else:
		for word in line:
			print(curr_chapter, word)